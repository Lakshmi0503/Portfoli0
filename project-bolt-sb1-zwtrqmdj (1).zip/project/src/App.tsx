import React from 'react';
import { Github, Linkedin, Mail, MapPin, Phone } from 'lucide-react';

function App() {
  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header/Hero Section */}
      <header className="bg-gradient-to-r from-blue-600 to-blue-800 text-white py-20">
        <div className="container mx-auto px-4">
          <h1 className="text-4xl font-bold mb-4">Lakshmi C P</h1>
          <p className="text-xl mb-6">Data Analyst & Cybersecurity Professional</p>
          <div className="flex flex-wrap gap-4 text-sm">
            <a href="mailto:lakshmicp1805@gmail.com" className="flex items-center gap-2 hover:text-blue-200">
              <Mail size={16} /> lakshmicp1805@gmail.com
            </a>
            <a href="tel:+919886106366" className="flex items-center gap-2 hover:text-blue-200">
              <Phone size={16} /> +91 9886106366
            </a>
            <span className="flex items-center gap-2">
              <MapPin size={16} /> Bengaluru, Karnataka
            </span>
            <a href="https://www.linkedin.com/in/lakshmi-cp-112189336" target="_blank" rel="noopener noreferrer" className="flex items-center gap-2 hover:text-blue-200">
              <Linkedin size={16} /> LinkedIn
            </a>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-12">
        {/* About Section */}
        <section className="mb-12">
          <h2 className="text-2xl font-bold mb-4 text-gray-800">Summary</h2>
          <p className="text-gray-600">
            Highly motivated and results-oriented professional seeking a challenging position within a dynamic firm. 
            Eager to leverage my proven skills in data analysis and cybersecurity to contribute significantly to business growth and 
            achieve ambitious objectives. Possess a strong work ethic, excellent communication and interpersonal skills, and a 
            proactive approach to problem-solving.
          </p>
        </section>

        {/* Skills Section */}
        <section className="mb-12">
          <h2 className="text-2xl font-bold mb-4 text-gray-800">Skills</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="bg-white p-6 rounded-lg shadow-sm">
              <h3 className="font-semibold mb-3 text-gray-700">Technical Skills</h3>
              <div className="flex flex-wrap gap-2">
                {['Power BI', 'Microsoft Excel', 'MySQL', 'Dashboard', 'PowerPoint', 'Tableau', 'Python'].map((skill) => (
                  <span key={skill} className="bg-blue-100 text-blue-800 px-3 py-1 rounded-full text-sm">
                    {skill}
                  </span>
                ))}
              </div>
            </div>
            <div className="bg-white p-6 rounded-lg shadow-sm">
              <h3 className="font-semibold mb-3 text-gray-700">Soft Skills</h3>
              <div className="flex flex-wrap gap-2">
                {['Analytical Thinking', 'Adaptability', 'Team Work', 'Communication', 'Observation'].map((skill) => (
                  <span key={skill} className="bg-green-100 text-green-800 px-3 py-1 rounded-full text-sm">
                    {skill}
                  </span>
                ))}
              </div>
            </div>
          </div>
        </section>

        {/* Experience Section */}
        <section className="mb-12">
          <h2 className="text-2xl font-bold mb-4 text-gray-800">Internship Experience</h2>
          <div className="space-y-6">
            <div className="bg-white p-6 rounded-lg shadow-sm">
              <div className="flex justify-between items-start mb-2">
                <h3 className="font-semibold text-gray-800">TATA STIVE</h3>
                <span className="text-sm text-gray-500">Aug 2024 – Nov 2024</span>
              </div>
              <ul className="list-disc list-inside text-gray-600 space-y-2">
                <li>Conducted Vulnerability assessment of web applications using OWASP ZAP and burp suite</li>
                <li>Implemented and configured Squid Proxy server to enhance network performance and security</li>
                <li>Performed security assessment on sample e-commerce applications</li>
                <li>Set up simulated network environments to detect and migrate MITM attacks</li>
              </ul>
            </div>

            <div className="bg-white p-6 rounded-lg shadow-sm">
              <div className="flex justify-between items-start mb-2">
                <h3 className="font-semibold text-gray-800">EXCELR Solutions</h3>
                <span className="text-sm text-gray-500">2023-2024</span>
              </div>
              <p className="font-medium mb-2">Healthcare Analysis Project</p>
              <ul className="list-disc list-inside text-gray-600 space-y-2">
                <li>Analyzed data related to total performance score and healthcare providers</li>
                <li>Created dashboards and reports using visualization tools like Tableau and Power BI</li>
                <li>Provided strategic recommendations based on analysis</li>
              </ul>
            </div>
          </div>
        </section>

        {/* Certifications Section */}
        <section className="mb-12">
          <h2 className="text-2xl font-bold mb-4 text-gray-800">Certifications</h2>
          <div className="bg-white p-6 rounded-lg shadow-sm">
            <ul className="list-disc list-inside text-gray-600 space-y-2">
              <li>Internship Project through Data Analyst Ai Variant from ExcelR (06th Feb 2024 to 06th May 2024)</li>
              <li>Data analyst Certification from ExcelR (11th March 2024)</li>
            </ul>
          </div>
        </section>

        {/* Education Section */}
        <section>
          <h2 className="text-2xl font-bold mb-4 text-gray-800">Education</h2>
          <div className="space-y-4">
            <div className="bg-white p-6 rounded-lg shadow-sm">
              <div className="flex justify-between items-start mb-2">
                <h3 className="font-semibold text-gray-800">Master of Computer Applications</h3>
                <span className="text-sm text-gray-500">2024-2025</span>
              </div>
              <p className="text-gray-600">Amity University, Bengaluru</p>
            </div>

            <div className="bg-white p-6 rounded-lg shadow-sm">
              <div className="flex justify-between items-start mb-2">
                <h3 className="font-semibold text-gray-800">Bachelor of Computer Applications</h3>
                <span className="text-sm text-gray-500">2023</span>
              </div>
              <p className="text-gray-600">Sindhi College, Bengaluru | CGPA: 9.5</p>
            </div>

            <div className="bg-white p-6 rounded-lg shadow-sm">
              <div className="flex justify-between items-start mb-2">
                <h3 className="font-semibold text-gray-800">Intermediate (2nd PUC)</h3>
                <span className="text-sm text-gray-500">2020</span>
              </div>
              <p className="text-gray-600">UAS & VC PU College | Percentage: 86.8%</p>
            </div>

            <div className="bg-white p-6 rounded-lg shadow-sm">
              <div className="flex justify-between items-start mb-2">
                <h3 className="font-semibold text-gray-800">SSLC (CBSE)</h3>
                <span className="text-sm text-gray-500">2018</span>
              </div>
              <p className="text-gray-600">Katherine Public School | Percentage: 78%</p>
            </div>
          </div>
        </section>
      </main>

      {/* Footer */}
      <footer className="bg-gray-800 text-white py-8 mt-12">
        <div className="container mx-auto px-4 text-center">
          <p>© 2024 Lakshmi C P. All rights reserved.</p>
        </div>
      </footer>
    </div>
  );
}

export default App;